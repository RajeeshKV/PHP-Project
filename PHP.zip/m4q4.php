<?php
	
	$mark=34;
	echo "Initial mark ".$mark;
	while ($mark < 40) {
		if($mark >32 && $mark <= 39){
			$mark++;
		}
	}
	echo "<br>final mark ".$mark;
?>