<?php

	$Name="        RAJEESH             ";


	echo strlen($Name);
	echo "<br>";
	echo strlen(trim($Name));
	//echo trim($Name);

?>