<?php

	
	function Multiplication($number,$endnumber){
		echo "<table border='1'>";
		for($i=1; $i<=$endnumber; $i++){
			echo "<tr align='center'><td>".$number."</td><td>X</td><td>".$i."</td><td>=</td><td>".$number*$i."</td></tr>";
		}
		echo "</table>";
	}

	Multiplication(10,15);
?>