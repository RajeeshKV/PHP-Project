<?php
$Name="Rajeesh";
echo "Hi {$Name}";
echo "<br>";
echo 'Hi {$Name}';
?>