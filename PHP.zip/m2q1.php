<?php

$Name="Rajeesh";
$Semester=5;
$Marks=88;

	echo $Name." of ".$Semester." semester has scored ".$Marks." in his/her exams";

?>