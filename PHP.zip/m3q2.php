<?php

	$my_arr  = array("Rajeesh", "Akshay", "Arjun", "Soorej", "Pavan", "Praveen", "Anurag", "Avinash", "Raghavan", "Sukumaran");
	echo $my_arr[0]."<br>";
	echo $my_arr[9];	
?>