<!DOCTYPE html>
<html>
<head>
	<title>Student details</title>
</head>
<body>
<center>
	<form action="<?php $_PHP_SELF ?>" method="post">
		<input type="text" name="science" placeholder="science mark"><br><br>
		<input type="text" name="maths" placeholder="maths mark"><br><br>
		<input type="submit" name="submit" value="submit"><br>
	</form>
</center>


<?php

	if (isset($_POST['submit'])) {
		
		$science = $_POST['science'];
		$maths = $_POST['maths'];

		echo "Total Marks: ".($science+$maths)."<br>";
		echo "Average Marks: ".($science+$maths)/2;

	}

?>
</body>
</html>