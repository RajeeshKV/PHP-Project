<?php

$str = "Ask not what your nation has done for you. Ask what you can do for your nation";
$str=str_replace("nation", "country", $str);
$count=substr_count($str, "country");
echo $str." <br> count: ".$count;

?>