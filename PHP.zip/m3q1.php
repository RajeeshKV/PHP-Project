<?php

	$my_arr = array("India"=>"Delhi", "Italy"=>"Rome" , "Germany" => "Berlin", "Belgium"=> "Brussels", "United Kingdom"=>"London");

	foreach ($my_arr as $key => $value) {
		echo $value."<br>";
	}

	echo "<br>".$my_arr["Belgium"];
?>