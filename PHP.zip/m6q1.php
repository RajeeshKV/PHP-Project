<?php
	
	$con = mysqli_connect("localhost","root","");
	$db_con = mysqli_select_db($con,"topgear");

	if($db_con){
		$query = "Select * from student";
		$sql = mysqli_query($con,$query);
		while ($row = $sql->fetch_assoc()) {
			echo "Name : ".$row['studentname']."     ";
			echo "Class : ".$row['class']."     ";
			echo "Mark : ".$row['mark']."<br><br>";
		}

		echo "<br>======Updating mark for student id 3========<br>";
		$update_query = "Update student set mark=66 where studentid=3";
		$update_sql= mysqli_query($con,$update_query);

		$query = "Select * from student";
		$sql = mysqli_query($con,$query);
		while ($row = $sql->fetch_assoc()) {
			echo "Name : ".$row['studentname']."     ";
			echo "Class : ".$row['class']."     ";
			echo "Mark : ".$row['mark']."<br><br>";
		}

		echo "<br>========Deleting the student with id 1========<br>";
		$delete_query = "delete from student where studentid=1";
		$delete_sql= mysqli_query($con,$delete_query);

		$query = "Select * from student";
		$sql = mysqli_query($con,$query);
		while ($row = $sql->fetch_assoc()) {
			echo "Name : ".$row['studentname']."     ";
			echo "Class : ".$row['class']."     ";
			echo "Mark : ".$row['mark']."<br><br>";
		}
	}
?>