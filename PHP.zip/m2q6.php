<?php

$name="Roger";
$city="Bangalore";

echo strtolower($name)." ".strtoupper($city);

?>