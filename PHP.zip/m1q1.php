<?php
		echo "Welcome to the PHP Training";
?>