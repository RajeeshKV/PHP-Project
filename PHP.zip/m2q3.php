<?php

echo "Sachin's 100<sup>th</sup> century";
echo "<br>";
echo 'Sachin\'s 100<sup>th</sup> century';

?>