<?php

$company="Wipro Limited";

echo strlen($company);

?>