<?php

	$my_arr  = array("Rajeesh", "Akshay", "Arjun", "Soorej", "Pavan", "Praveen", "Anurag", "Avinash", "Raghavan", "Sukumaran");
	
	array_shift($my_arr);

	echo count($my_arr)."<br>";

	for($i=0;$i<count($my_arr);$i++){
		echo $my_arr[$i]." ";
	}
?>