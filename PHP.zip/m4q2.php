<?php

	$appraisal = "ECC";

	if($appraisal=="OS"){
		echo "15% hike";
	}
	elseif ($appraisal=="ECC") {
		echo "10% hike";
	}
	elseif ($appraisal=="HVC") {
		echo "5% hike";
	}
	else {
		echo "Sorry No Hike";
	}

?>