<?php

	
	function Multiplication($n){
		echo "<table border='1'>";
		for($i=1; $i<=10; $i++){
			echo "<tr align='center'><td>".$n."</td><td>X</td><td>".$i."</td><td>=</td><td>".$n*$i."</td></tr>";
		}
		echo "</table>";
	}

	Multiplication(15);
?>