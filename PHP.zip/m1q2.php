<?php
$firstName="Rajeesh";
$lastName="KV";
echo "Welcome to the training ".$firstName." ".$lastName;
?>