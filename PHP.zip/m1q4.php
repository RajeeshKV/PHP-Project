<?php
define("MINMARKS", 0);
define("MAXMARKS", 100);
echo MINMARKS." ".MAXMARKS;
define("MINMARKS", 1);
echo MINMARKS;
?>