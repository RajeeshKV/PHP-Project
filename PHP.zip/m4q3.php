<?php
	echo "====For Loop=====<br>";
	for ($i=2; $i<=100 ; $i+=2) { 
		echo $i." ";
	}

	echo "<br>====While Loop=====<br>";
	$i=2;
	while ($i<=100) {
		echo $i." ";
		$i+=2;
	}
?>