<?php

	$str1 = "balls can also be used for simpler activities, such as catch or juggling";
	$str2 = "ask not what your country has done for you. Ask what you can do for your country";
	$str3 = "Hello123worl234d";
	if(strrpos($str1, "ball") !== false){
		echo $str1;
	}
	if(strrpos($str2, "ball") !== false){
		echo $str2;
	}

	$str2 = str_replace("country", "nation",$str2);
	echo "<br>".$str2;

	preg_match_all('/(?<!\d)\d{3}(?!\d)/',$str3,$value_extracted);
		echo "<br>";
		$keys = array_keys($value_extracted);
		for($i = 0; $i < count($value_extracted); $i++) {
    		foreach($value_extracted[$keys[$i]] as $key => $value) {
        		echo $value . "<br>";
    }
    echo "<br>";
}
?>