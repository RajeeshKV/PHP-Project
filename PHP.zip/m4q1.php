<?php

	$mark=80;

	if($mark>40){
		echo "passed";
	}
	else {
		echo "failed";
	}

?>