<?php

	$my_arr = array(
		"Rajeesh"=>array('class' => "8", "Phone"=>"9876543210", "Mark"=>"88"),
		"Akshay"=>array('class' => "10", "Phone"=>"9845671230", "Mark"=>"83"),
		"Arjun"=>array('class' => "9", "Phone"=>"8794561230", "Mark"=>"75"),
		"Pavan"=>array('class' => "7", "Phone"=>"7896541023", "Mark"=>"93"),
		"Soorej"=>array('class' => "10", "Phone"=>"8547963210", "Mark"=>"66")
	);

$keys = array_keys($my_arr);
for($i = 0; $i < count($my_arr); $i++) {
    echo "Name: ".$keys[$i] . "<br>";
    foreach($my_arr[$keys[$i]] as $key => $value) {
        echo $key . " : " . $value . "<br>";
    }
    echo "<br>";
}

  echo "<br>".$my_arr["Arjun"]["Phone"];
?>