<?php

$sciencemarks=77;
$mathsmarks=83;

echo ($sciencemarks>$mathsmarks? "Science is highest": "Maths is highest");
?>